from Models.Card import Card
from Models.Syndicate import Syndicate
from Models.Company import Company
from Models.Pouch import Pouch
from random import randint
from datetime import date, timedelta
'''
for cont in range(1, 5):
    regcard: Card = Card(cont, 'card' + str(cont))
    Card.insertdb(regcard)
print('FIM CARD')

for cont in range(1, 6):
    regsynd: Syndicate = Syndicate(cont, 'synd' + str(cont))
    Syndicate.insertdb(regsynd)
print('FIM SYNDICATE')

for synd in range(1, 6):
    for cont in range(1, 9):
        regcomp: Company = Company(synd, cont, 'comp' + str(synd) + str(cont))
        Company.insertdb(regcomp)
print('FIM COMPANY')

dtliminf = date(2020, 1, 1)
dt = dtliminf
dtlimsup = date(2020, 12, 31)
cont: int = 0
while dt <= dtlimsup:
    for card in range(1, 5):
        for synd in range(1, 6):
            for comp in range(1, 9):
                cont += 1
                codepouch: str = str(cont)
                quant: int = randint(1, 1000)
                valor: float = randint(1, 10000)
                if valor > 1000:
                    valor = valor / 100
                regpouch: Pouch = Pouch(codepouch, card, synd, comp, dt, quant, valor)
                Pouch.insertdb(regpouch)
    dt += timedelta(days=1)
    print(dt)
print('FIM POUCH')
'''
