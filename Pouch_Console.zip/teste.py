#import matplotlib.pyplot as plt
import numpy as np
from pandas import DataFrame

#field = '2020-01'
#month = field[-2:]
#year = field[:4]
#print(month)
#print(year)

x = [2, 4, 6, 8, 10]
y = [6, 7, 8, 2, 4]

dct = {}
dct = {'y': y, 'x': x}
print(dct)

frame = DataFrame(dct)
print(frame)
h = frame['y']
print(frame['y'])
print(h)
#plt.bar(x, y, label='Barras', color='g')
#plt.legend()
#plt.grid = True
#plt.show()

#dt = '2021-10-01'
#month = dt[5:7]
#print(month)
#frase = 'Curso em Video Python'
#fr = frase[3:13]
#print(fr)
'''
lst = np.zeros(12)
#for cont in range(1, 13):
#    np.append(lst, 0)
print(lst)
lst[4] = 40
print(lst)

lstquant = np.append([[2, 4, 6, 8, 10]], [[6, 7, 8, 2, 4]], axis=0)
lstquant2 = np.append([x], [y], axis=0)
lstquant3 = np.array([])

lst = []
for reg in range(1, 5):
    lst.append(reg)
print(sum(lst) / len(lst))
print(lst)
for reg in range(1, len(lst) + 1):
    lstquant3 = np.append(lstquant3, reg)
print(lstquant3.mean())
#print(lstquant)
#print(lstquant2)
print(lstquant3)

frase = 'Curso em Video Python'
print(frase[3])
print(frase[3:13])  # da posição 3 até à 12
print(frase[:13])   # do inicio ate à 12
print(frase[13:])   # da posição 13 até o final
print(frase[1:15:2]) # da posição 1 até a 15 pulando de 2 em 2
print(frase[1::2])   # da posição 1 até o final pulando de 2 em 2
print(frase[::2])    # da posição inicial ate´o final pulando de 2 2m 2
print(frase.count('o')) # conta a quantidade de 'o'
print(frase.upper().count('O'))  # conta a quantidade de 'O'
print(len(frase))  # conta a quantidade de caracteres
print(frase.split())  # tira os espacos em branco no inicio e no final
print(frase.replace('Python','Android'))  # substitui
print('Curso' in frase)  # verifica se existe
print(frase.find('Curso')) # verifica a posição inicial
print(frase.upper().find('VIDEO'))
dividido = frase.split()
print(dividido[0]) # mostra o elemento da lista na posição zero
print(dividido[2][3]) # mostra no elemento 2 da lista o caracter na posição 4
'''
